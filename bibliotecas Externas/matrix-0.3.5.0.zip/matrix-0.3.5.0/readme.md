# matrix package #

Haskell Matrix library with common operations with them.

Usage examples are populating the API reference.
